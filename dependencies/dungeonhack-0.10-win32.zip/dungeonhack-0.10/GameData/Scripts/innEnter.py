showMessage("The inn is suprisingly quiet for this time of day. You call out for the innkeep but get no response.")
