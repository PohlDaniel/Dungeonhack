Things you need on your path to build the SDK:

- Nullsoft Installer
- Doxygen
- HTML Help Compiler

Files you need:

- A complete clean build of all the OGRE libraries and samples
- chiropteraDM.pk3 and chiropteraDM.txt, in Samples/Media/packs
