#define PACKAGE_BUGREPORT "http://sourceforge.net/p/winflexbison/tickets"
#define VERSION "2.7"
#define PACKAGE_COPYRIGHT_YEAR 2012
#define LOCALEDIR ""
#define PACKAGE_STRING "bison"
#define PACKAGE_URL "http://sourceforge.net/projects/winflexbison/"
#define PACKAGE ""
#define PACKAGE_VERSION "2.7"
#define PACKAGE_NAME "bison"
#define PKGDATADIR "data"
#define RENAME_OPEN_FILE_WORKS 1

#define ssize_t ptrdiff_t
