Fork of the [ALURE](http://kcat.strangesoft.net/alure.html) 1.2 library used in [RVGL](http://rvgl.re-volt.io).
