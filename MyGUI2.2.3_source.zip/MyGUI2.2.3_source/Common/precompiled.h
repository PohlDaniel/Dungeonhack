#include <vector>
#include <Ogre.h>
#include <OIS/OIS.h>
#include <MyGUI.h>
