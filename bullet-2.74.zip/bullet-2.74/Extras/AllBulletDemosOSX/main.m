//
//  main.m
//  AllBulletDemos
//
//  Created by Shamyl Zakariya on 5/1/08.
//  Copyright Shamyl Zakariya 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
