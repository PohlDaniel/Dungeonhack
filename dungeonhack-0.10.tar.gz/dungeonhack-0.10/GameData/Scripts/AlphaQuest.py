
questName = "NecroQuest"

if questExists(questName) == False:
  addQuest(questName,"simpleTestQuestDef.py")
