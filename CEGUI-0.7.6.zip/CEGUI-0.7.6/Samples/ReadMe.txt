This ReadMe lists the items in the Samples directory and describes what the sample applications are.

bin           - directory to receive final executables.
common        - directory containing source code for the samples support framework.
datafiles     - directory containing all the data files used by the samples, plus additional sample files.
Demo4         - A version of the original CEGUI Mk-2 preview application "Demo4"
Demo6         - A version of the original CEGUI Mk-2 preview application "Demo6"
Demo7         - A version of the original CEGUI Mk-2 preview application "Demo7"
Demo8         - A version of the original CEGUI Mk-2 preview application "Demo8"
FalagardDemo1 - A sample application showing the Falagard skinning system in use.
FirstWindow   - Initial sample app showing initialisation of data files and creation of a simple window.
FontDemo      - A demonstration of what the Font rendering subsystem can do
